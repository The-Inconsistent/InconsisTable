# @the-inconsistent/client

The server-side SDK a relying party (InconsisTable's api and its sibling apps) uses to sign users in with InconsisID.
It wraps `openid-client` and `jose` around InconsisID's client contract (`docs/client-contract.md` in the InconsisID
repo): authorization code with
PKCE, `private_key_jwt` ES256, ID token checks, admin step-up, back-channel and RP-initiated logout.

The SDK is stateless. It hands you a transaction to store and reads it back; it keeps no sessions, no cookies and no
replay table. Those are yours (see "What you store and check").

Plain ESM with type declarations. Runs on Node >= 22.18 and Bun 1.3.

## Install

The package is private, on GitHub Packages under the `The-Inconsistent` org. You need read access to it.

In your app, add an `.npmrc` (commit it; it holds no secret):

```ini
@the-inconsistent:registry=https://npm.pkg.github.com
//npm.pkg.github.com/:_authToken=${NODE_AUTH_TOKEN}
```

Then `bun add @the-inconsistent/client` (or `npm install`), with `NODE_AUTH_TOKEN` set.

**Locally.** Give the GitHub CLI the `read:packages` scope once, then export its token:

```bash
gh auth refresh -h github.com -s read:packages
export NODE_AUTH_TOKEN=$(gh auth token)
```

**In your GitHub Actions.** Grant your repo read access first: package settings (org packages page, `client`, Package
settings, Manage Actions access) and add the repo with the Read role. Then the workflow reads with its own token:

```yaml
permissions:
  contents: read
  packages: read
steps:
  - run: bun install --frozen-lockfile
    env:
      NODE_AUTH_TOKEN: ${{ secrets.GITHUB_TOKEN }}
```

Its dependencies are `openid-client`, `jose` and `zod`, pinned exactly.

## Find the package

After a publish it is listed on the org's packages page (`https://github.com/orgs/The-Inconsistent/packages`) and in
the Packages sidebar of the InconsisID repo. It inherits the repo's private visibility through `repository` in its
`package.json`.

## Release (maintainers)

1. Bump `version` in `packages/client/package.json` and commit it.
2. Tag the commit `client-vX.Y.Z`, the same version, and push the tag: `git tag client-v0.1.1 && git push origin client-v0.1.1`.
3. `.github/workflows/publish-client.yml` fails if the tag and the version differ, builds, and runs `npm publish` with the
   workflow's `GITHUB_TOKEN`. A version cannot be published twice; bump it again.

## Register your client

Clients are static. Open a PR on InconsisID that adds `clients/<your-app>.ts`, modelled on `clients/dev-test.ts`, and
lists it in `clients/clients.ts`. It holds:

- your public JWK (`jwks`), with `token_endpoint_auth_method: "private_key_jwt"` and ES256;
- the exact `redirect_uris` (your callback) and `post_logout_redirect_uris`;
- `backchannel_logout_uri` with `backchannel_logout_session_required: true`;
- `first_party: true`, so no consent page is shown.

**The back-channel URI must be reachable at a public address.** The IdP refuses to deliver logout tokens to loopback or
private addresses (its SSRF guard stays on, see the contract's known deviations). Expose the endpoint through your
public reverse proxy. If the IdP cannot reach it, you get no logout tokens and your sessions last until they expire.

## Secrets

One file: your private ES256 JWK (`kty` `EC`, `crv` `P-256`, `kid`, `x`, `y`, `d`). Its public half goes in your client
file. Generate a pair once:

```ts
import { exportJWK, generateKeyPair } from "jose";
const { privateKey } = await generateKeyPair("ES256", { extractable: true });
const jwk = { ...(await exportJWK(privateKey)), kid: crypto.randomUUID(), alg: "ES256", use: "sig" };
console.log(JSON.stringify(jwk)); // the private file; drop "d" for the public JWK
```

Keep the file out of the repo and out of environment variables; read it from a secrets directory at boot.

## Flow

```ts
import { readFileSync } from "node:fs";
import { createIdpClient, IdpError } from "@the-inconsistent/client";

const ISSUER = "https://auth.example";

// Once at boot. Throws IdpError (discovery_failed, discovery_mismatch) unless the IdP's discovery matches the contract.
const idp = await createIdpClient({
  issuer: ISSUER,
  clientId: "inconsistable",
  privateJwk: JSON.parse(readFileSync("/run/secrets/idp_client_jwk.json", "utf8")),
  redirectUri: "https://app.example/api/auth/callback",
  postLogoutRedirectUri: "https://app.example/",
});

// POST, not GET, so a foreign link cannot start a sign-in.
app.post("/api/auth/login", async (req, res) => {
  if (req.get("sec-fetch-site") !== "same-origin") return res.sendStatus(403);
  const { url, transaction } = await idp.startSignIn({ purpose: "signin" }); // or "admin_stepup"
  const handle = randomHandle(); // 128 bits
  await db.oidcTx.insert({ handleHash: sha256(handle), transaction, returnTo: safeReturnTo(req.body.returnTo) });
  res.cookie("__Host-app_oidc_tx", handle, { httpOnly: true, secure: true, path: "/", sameSite: "lax", maxAge: 600_000 });
  res.redirect(303, url.href);
});

app.get("/api/auth/callback", async (req, res) => {
  // One use, this browser only: delete the row and read it in one statement.
  const row = await db.oidcTx.deleteReturning(sha256(req.cookies["__Host-app_oidc_tx"] ?? ""));
  res.clearCookie("__Host-app_oidc_tx", { path: "/" });
  if (!row) return res.status(400).send("Sign-in failed. Start again.");
  try {
    const signIn = await idp.finishSignIn(req.originalUrl, row.transaction);
    // signIn: { iss, sub, sid, authTime, acr, amr, roles }
    const user = await linkIdentity(signIn.iss, signIn.sub);
    await startSession(res, user, { opSid: signIn.sid, roles: signIn.roles, acr: signIn.acr });
    res.redirect(303, row.returnTo);
  } catch (error) {
    if (!(error instanceof IdpError)) throw error;
    log.warn({ code: error.code, cause: error.cause });
    res.status(400).send("Sign-in failed. Start again.");
  }
});

app.post("/api/auth/logout", async (req, res) => {
  await endSession(req);
  res.redirect(303, idp.logoutUrl().href); // the IdP asks the user to confirm
});

// form-encoded: logout_token=<jwt>
app.post("/api/auth/backchannel-logout", async (req, res) => {
  res.set("Cache-Control", "no-store");
  try {
    const { sub, sid, jti, exp } = await idp.verifyLogoutToken(String(req.body.logout_token));
    if (!(await db.logoutJti.insertIfAbsent(jti, exp))) return res.sendStatus(400); // replay
    if (sid) await endSessionsByOpSid(sid);
    else await endSessionsOf(ISSUER, sub!);
    res.sendStatus(200);
  } catch {
    res.sendStatus(400);
  }
});
```

A NestJS controller has the same four handlers.

## What the SDK checks

`finishSignIn(callbackUrl, transaction)` stops at the first failure, in this order:

1. the transaction parses and is at most 10 minutes old;
2. `state` matches;
3. `iss` is present and equals the issuer exactly (RFC 9207);
4. the code is exchanged with the PKCE verifier, authenticated with `private_key_jwt`;
5. the ID token: ES256 from the issuer's JWKS, `iss`, `aud` (and `azp` when there are several audiences), `exp`, `iat`
   with 30 s of clock tolerance, `nonce`;
6. `acr` is one of the two known values; `roles` keeps only `admin` and `creator`, dropping unknown values;
7. for `admin_stepup`: `acr` is `urn:inconsistable:acr:passkey-uv` and `auth_time` is at most 300 s old. The request
   already asked for `max_age=0` and that `acr`; this checks the IdP honoured it.

`callbackUrl` may be the full URL or the path and query (`req.originalUrl`); the code is redeemed against the
registered `redirectUri` either way.

`verifyLogoutToken(token)` checks header `typ` `logout+jwt`, ES256 from the issuer's JWKS, `iss`, `aud` equal to your
client id, `iat` at most 2 minutes old and `exp` with 30 s of tolerance, a `jti`, the back-channel event in `events`,
no `nonce`, and a `sub` or a `sid`. It returns `{ sub, sid, jti, exp }`.

`logoutUrl({ state })` is the IdP's `end_session_endpoint` with `client_id` and your registered
`post_logout_redirect_uri`. It sends no `id_token_hint`: you keep no ID tokens.

## What you store and check

| What | Where | Rule |
|---|---|---|
| The transaction | A row keyed by the hash of a 128-bit handle in a `__Host-` cookie (`HttpOnly`, `Secure`, `SameSite=Lax`, 10 min) | Deleted on first read; the SDK refuses one older than 10 minutes, but only you can make it single-use and bound to the browser. |
| `return_to` | Next to the transaction | A relative path starting with a single `/` (no `//`, no `/\`) from your own route list. |
| Identity link | Your users table | Key on `(iss, sub)`. `sub` is opaque and never reused. |
| `sid` | Your session row | A logout token with `sid` ends that session; one with only `sub` ends all of that user's sessions. |
| `jti` | A table with `jti` as the key and `exp` | Insert on conflict do nothing; a duplicate is a replay (answer 400). Prune rows past `exp`. |
| `acr` | Your session row | Allow nothing sensitive on `urn:inconsistable:acr:recovery`. Admin actions need a fresh `admin_stepup`. |

Do not store the ID token or the access token; everything you need is in the `finishSignIn` result.

## Errors

Every refusal is an `IdpError` with a stable `code` (`IdpErrorCode.options`) and a generic message; `cause` holds the
library's detail for your logs, not for the user.

| Code | Meaning |
|---|---|
| `discovery_failed` | Discovery could not be fetched or parsed. |
| `discovery_mismatch` | The issuer differs, or the IdP lacks the `iss` parameter, ES256 ID tokens or PKCE S256. |
| `transaction_invalid` | The stored transaction is not one `startSignIn` made. |
| `transaction_expired` | Older than 10 minutes. |
| `state_mismatch` | The callback's `state` is missing or different. |
| `issuer_mismatch` | The callback's `iss` is missing or different. |
| `authorization_denied` | The IdP sent an error back instead of a code. |
| `code_exchange_failed` | The token endpoint refused (a replayed or expired code, a wrong verifier) or could not be reached. |
| `id_token_invalid` | The token response or the ID token failed a check. |
| `step_up_required` | An `admin_stepup` came back without a fresh passkey sign-in. |
| `logout_token_invalid` | The logout token failed a check. |

The closed sets are exported as zod enums: `Role`, `Acr`, `Purpose`, `IdpErrorCode`.

## Plain HTTP

`openid-client` refuses plain HTTP. The SDK allows it only for an issuer on `localhost`, `127.0.0.1` or `[::1]`, so a
local IdP (`http://localhost:4100`) works and nothing else does.
